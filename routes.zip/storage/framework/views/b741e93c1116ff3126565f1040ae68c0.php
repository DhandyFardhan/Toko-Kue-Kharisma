<div class="product-card">
    <div class="product-image-container">
        <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="product-image">
    </div>
    <div class="product-info">
        <h3 class="product-name"><?php echo e($product->name); ?></h3>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($showDescription)): ?>
            <p class="product-description"><?php echo e($product->description); ?></p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <p class="product-price">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></p>
        <div class="product-actions">
            <button type="button" class="btn-add-cart" data-product-id="<?php echo e($product->id); ?>" data-product-name="<?php echo e($product->name); ?>" data-product-price="<?php echo e($product->price); ?>" <?php if(isset($buttonOnclick)): ?> onclick='<?php echo $buttonOnclick; ?>' <?php endif; ?>>
                <svg viewBox="0 0 24 24">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                </svg>
                <?php echo e($buttonLabel ?? 'Masukkan ke keranjang'); ?>

            </button>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Toko-Kue-Kharisma\resources\views/partials/product-card.blade.php ENDPATH**/ ?>